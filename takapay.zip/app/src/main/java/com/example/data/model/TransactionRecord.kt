package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "DEPOSIT", "WITHDRAW", "GAME_BET", "GAME_WIN"
    val amount: Double,
    val method: String, // "bKash", "Nagad", "Ludo Game", "Word Task", "Ball Game"
    val trxId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Completed", // "Completed", "Pending"
    val note: String = ""
)
