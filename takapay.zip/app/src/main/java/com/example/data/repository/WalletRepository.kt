package com.example.data.repository

import com.example.data.local.TransactionDao
import com.example.data.local.UserDao
import com.example.data.model.TransactionRecord
import com.example.data.model.UserProfile
import com.example.security.SecurityManager
import kotlinx.coroutines.flow.Flow

class WalletRepository(
    private val userDao: UserDao,
    private val transactionDao: TransactionDao
) {
    val userProfile: Flow<UserProfile?> = userDao.getUserProfile()
    val allTransactions: Flow<List<TransactionRecord>> = transactionDao.getAllTransactions()

    suspend fun ensureDefaultUser() {
        val current = userDao.getUserProfileOnce()
        if (current == null) {
            val defaultUser = UserProfile(
                id = 1,
                name = "রাকিবুল হাসান",
                phone = "01712345678",
                pin = "1234",
                gender = "MALE",
                balance = 200.0,
                twoFactorEnabled = true,
                twoFactorPin = "1234",
                totalDeposited = 200.0,
                totalWithdrawn = 0.0,
                totalWon = 0.0,
                isLoggedIn = false,
                lastRewardClaimTime = 0L,
                rewardClaimCount = 0
            )
            userDao.insertOrUpdateProfile(defaultUser)
            // Add initial welcome deposit record
            transactionDao.insertTransaction(
                TransactionRecord(
                    type = "DEPOSIT",
                    amount = 200.0,
                    method = "bKash",
                    trxId = "BK" + SecurityManager.generateTrxId("INIT"),
                    status = "Completed",
                    note = "স্বাগতম ব্যালেন্স (বিকাশ ভেরিফাইড)"
                )
            )
        }
    }

    suspend fun depositMoney(
        amount: Double,
        method: String,
        trxId: String,
        senderNumber: String
    ): Result<UserProfile> {
        val user = userDao.getUserProfileOnce() ?: return Result.failure(Exception("ব্যবহারকারী পাওয়া যায়নি"))
        if (amount < 10) {
            return Result.failure(Exception("সর্বনিম্ন ডিপোজিট ১০ টাকা"))
        }

        val updatedBalance = user.balance + amount
        val updatedDeposited = user.totalDeposited + amount
        val updatedUser = user.copy(
            balance = updatedBalance,
            totalDeposited = updatedDeposited
        )
        userDao.insertOrUpdateProfile(updatedUser)

        val cleanTrxId = if (trxId.isBlank()) SecurityManager.generateTrxId(if (method.contains("Nagad", true)) "NG" else "BK") else trxId.trim().uppercase()

        transactionDao.insertTransaction(
            TransactionRecord(
                type = "DEPOSIT",
                amount = amount,
                method = method,
                trxId = cleanTrxId,
                status = "Completed",
                note = "অটো ডিপোজিট সম্পন্ন ($senderNumber)"
            )
        )

        return Result.success(updatedUser)
    }

    suspend fun withdrawMoney(
        amount: Double,
        method: String,
        targetNumber: String,
        twoFactorPin: String
    ): Result<UserProfile> {
        val user = userDao.getUserProfileOnce() ?: return Result.failure(Exception("ব্যবহারকারী পাওয়া যায়নি"))

        if (user.twoFactorEnabled) {
            if (twoFactorPin.trim() != user.twoFactorPin.trim()) {
                return Result.failure(Exception("ভুল 2FA সিকিউরিটি পিন! সঠিক পিন প্রদান করুন।"))
            }
        }

        if (amount < 50) {
            return Result.failure(Exception("সর্বনিম্ন উইথড্র ৫০ টাকা"))
        }

        if (user.balance < amount) {
            return Result.failure(Exception("অপর্যাপ্ত ব্যালেন্স! আপনার একাউন্টে পর্যাপ্ত টাকা নেই।"))
        }

        val updatedBalance = user.balance - amount
        val updatedWithdrawn = user.totalWithdrawn + amount
        val updatedUser = user.copy(
            balance = updatedBalance,
            totalWithdrawn = updatedWithdrawn
        )
        userDao.insertOrUpdateProfile(updatedUser)

        val trxId = SecurityManager.generateTrxId("WD")
        transactionDao.insertTransaction(
            TransactionRecord(
                type = "WITHDRAW",
                amount = amount,
                method = method,
                trxId = trxId,
                status = "Completed",
                note = "উইথড্র সম্পন্ন ($targetNumber) [2FA সিকিউরড]"
            )
        )

        return Result.success(updatedUser)
    }

    suspend fun applyGameResult(
        gameName: String,
        betAmount: Double,
        isWin: Boolean
    ): Result<Double> {
        val user = userDao.getUserProfileOnce() ?: return Result.failure(Exception("ব্যবহারকারী পাওয়া যায়নি"))

        if (betAmount < 50) {
            return Result.failure(Exception("লুডু ও অন্যান্য গেম এ সর্বনিম্ন ৫০ টাকা দিয়ে খেলতে হবে"))
        }

        if (!isWin && user.balance < betAmount) {
            return Result.failure(Exception("খেলার জন্য পর্যাপ্ত ব্যালেন্স নেই! দয়া করে রিচার্জ করুন।"))
        }

        if (isWin) {
            // ৫০ দিয়ে খেললে ১০০ যাবে + ১% বেশি বোনাস = ৫০ * ২ + (৫০ * ০.০১) = ১০১.০০ টাকা payout (নেট প্রফিট ৫১ টাকা)
            val bonusRate = 0.01 // 1% extra bonus on account
            val totalWinPayout = (betAmount * 2.0) + (betAmount * bonusRate)
            val netAddition = totalWinPayout - betAmount // net profit added to balance

            val updatedBalance = user.balance + netAddition
            val updatedWon = user.totalWon + totalWinPayout
            val updatedUser = user.copy(
                balance = updatedBalance,
                totalWon = updatedWon
            )
            userDao.insertOrUpdateProfile(updatedUser)

            val trxId = SecurityManager.generateTrxId("WIN")
            transactionDao.insertTransaction(
                TransactionRecord(
                    type = "GAME_WIN",
                    amount = totalWinPayout,
                    method = gameName,
                    trxId = trxId,
                    status = "Completed",
                    note = "বিজয়ী পুরস্কার: ১০০% ডাবল + ১% এক্সট্রা বোনাস"
                )
            )
            return Result.success(totalWinPayout)
        } else {
            // Player lost: bet amount is deducted
            val updatedBalance = (user.balance - betAmount).coerceAtLeast(0.0)
            val updatedUser = user.copy(balance = updatedBalance)
            userDao.insertOrUpdateProfile(updatedUser)

            val trxId = SecurityManager.generateTrxId("BET")
            transactionDao.insertTransaction(
                TransactionRecord(
                    type = "GAME_BET",
                    amount = betAmount,
                    method = gameName,
                    trxId = trxId,
                    status = "Completed",
                    note = "গেমে পরাজয়: বাজি কয়েন কাটা হয়েছে"
                )
            )
            return Result.success(-betAmount)
        }
    }

    suspend fun updateProfile(
        name: String,
        phone: String,
        pin: String,
        twoFactorPin: String,
        twoFactorEnabled: Boolean,
        gender: String = "MALE"
    ): Result<UserProfile> {
        val user = userDao.getUserProfileOnce() ?: return Result.failure(Exception("ব্যবহারকারী পাওয়া যায়নি"))
        val updated = user.copy(
            name = name.ifBlank { user.name },
            phone = phone.ifBlank { user.phone },
            pin = pin.ifBlank { user.pin },
            twoFactorPin = twoFactorPin.ifBlank { user.twoFactorPin },
            twoFactorEnabled = twoFactorEnabled,
            gender = gender.ifBlank { user.gender }
        )
        userDao.insertOrUpdateProfile(updated)
        return Result.success(updated)
    }

    suspend fun setGender(gender: String): Result<UserProfile> {
        val user = userDao.getUserProfileOnce() ?: return Result.failure(Exception("ব্যবহারকারী পাওয়া যায়নি"))
        val updated = user.copy(gender = gender)
        userDao.insertOrUpdateProfile(updated)
        return Result.success(updated)
    }

    suspend fun claimLoyaltyReward(): Result<Double> {
        val user = userDao.getUserProfileOnce() ?: return Result.failure(Exception("ব্যবহারকারী পাওয়া যায়নি"))
        val rewardAmount = 20.0
        val updatedBalance = user.balance + rewardAmount
        val updatedCount = user.rewardClaimCount + 1
        val updatedUser = user.copy(
            balance = updatedBalance,
            lastRewardClaimTime = System.currentTimeMillis(),
            rewardClaimCount = updatedCount
        )
        userDao.insertOrUpdateProfile(updatedUser)

        val trxId = SecurityManager.generateTrxId("RWD")
        transactionDao.insertTransaction(
            TransactionRecord(
                type = "REWARD",
                amount = rewardAmount,
                method = "Loyalty Bonus",
                trxId = trxId,
                status = "Completed",
                note = "২-৩ দিন পর পর উপস্থিতি উপহার বোনাস (৳২০ নগদ)"
            )
        )
        return Result.success(rewardAmount)
    }

    suspend fun loginOrRegister(name: String, phone: String, pin: String, gender: String = "MALE"): Result<UserProfile> {
        val existing = userDao.getUserProfileOnce()
        val user = if (existing != null) {
            existing.copy(
                name = name.ifBlank { existing.name },
                phone = phone.ifBlank { existing.phone },
                pin = pin.ifBlank { existing.pin },
                gender = gender.ifBlank { existing.gender },
                isLoggedIn = true
            )
        } else {
            UserProfile(
                id = 1,
                name = name.ifBlank { "নতুন ইউজার" },
                phone = phone.ifBlank { "01700000000" },
                pin = pin.ifBlank { "1234" },
                gender = gender.ifBlank { "MALE" },
                balance = 100.0,
                twoFactorEnabled = true,
                twoFactorPin = pin.ifBlank { "1234" },
                isLoggedIn = true,
                lastRewardClaimTime = 0L,
                rewardClaimCount = 0
            )
        }
        userDao.insertOrUpdateProfile(user)
        return Result.success(user)
    }

    suspend fun logout() {
        val existing = userDao.getUserProfileOnce()
        if (existing != null) {
            userDao.insertOrUpdateProfile(existing.copy(isLoggedIn = false))
        }
    }
}
