package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "ইউজার",
    val phone: String = "01700000000",
    val pin: String = "1234",
    val gender: String = "MALE", // "MALE" (ছেলে) or "FEMALE" (মেয়ে)
    val balance: Double = 100.0,
    val twoFactorEnabled: Boolean = true,
    val twoFactorPin: String = "1234",
    val totalDeposited: Double = 0.0,
    val totalWithdrawn: Double = 0.0,
    val totalWon: Double = 0.0,
    val isLoggedIn: Boolean = false,
    val lastRewardClaimTime: Long = 0L,
    val rewardClaimCount: Int = 0
)
