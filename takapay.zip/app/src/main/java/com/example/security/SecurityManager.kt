package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.security.MessageDigest

object SecurityManager {
    const val OFFICIAL_MERCHANT_NUMBER = "01843840404"
    const val CUSTOMER_SERVICE_PHONE = "01864911906"
    const val TELEGRAM_CHANNEL_URL = "https://t.me/+8801864911906"
    private const val SECRET_SALT = "TakaPay_Secure_Shield_2026_Salt"

    /**
     * Generates a cryptographic verification token for the merchant number
     * to protect against client-side injection and number tampering.
     */
    fun getSecurityChecksum(number: String = OFFICIAL_MERCHANT_NUMBER): String {
        return try {
            val bytes = (number + SECRET_SALT).toByteArray()
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(bytes)
            digest.take(6).joinToString("") { "%02X".format(it) }
        } catch (e: Exception) {
            "SEC8404AF"
        }
    }

    /**
     * Checks if the target number is the authentic, non-tampered merchant number.
     */
    fun isAuthenticMerchant(number: String): Boolean {
        return number.trim().replace("-", "").replace(" ", "") == OFFICIAL_MERCHANT_NUMBER
    }

    /**
     * Formatted display with masked security shield
     */
    fun formatMaskedNumber(number: String = OFFICIAL_MERCHANT_NUMBER): String {
        if (number.length >= 11) {
            val prefix = number.substring(0, 5)
            val suffix = number.substring(5)
            return "$prefix-$suffix"
        }
        return number
    }

    /**
     * Generates a simulated realistic bKash / Nagad Transaction ID
     */
    fun generateTrxId(prefix: String = "BK"): String {
        val allowedChars = ('A'..'Z') + ('0'..'9')
        val randomString = (1..8)
            .map { allowedChars.random() }
            .joinToString("")
        return "${prefix}${randomString}"
    }

    /**
     * Verifies 2FA PIN
     */
    fun verify2fa(inputPin: String, actualPin: String): Boolean {
        return inputPin.trim() == actualPin.trim()
    }

    /**
     * Opens user's Telegram channel or support chat for 01864911906
     */
    fun openTelegramCustomerService(context: Context, phone: String = CUSTOMER_SERVICE_PHONE) {
        val cleanPhone = phone.replace("+", "").replace("-", "").replace(" ", "")
        val telegramUri = Uri.parse("https://t.me/+88$cleanPhone")
        
        try {
            val intent = Intent(Intent.ACTION_VIEW, telegramUri).apply {
                setPackage("org.telegram.messenger")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, telegramUri)
                context.startActivity(fallbackIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "টেলিগ্রাম অ্যাপ বা ব্রাউজার খুলতে সমস্যা হয়েছে। নাম্বার: $phone", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Dials customer service number directly
     */
    fun dialCustomerService(context: Context, phone: String = CUSTOMER_SERVICE_PHONE) {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phone")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "ডায়াল করা সম্ভব হয়নি", Toast.LENGTH_SHORT).show()
        }
    }
}
