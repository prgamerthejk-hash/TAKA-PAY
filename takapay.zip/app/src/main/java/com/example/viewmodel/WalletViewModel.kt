package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.TransactionRecord
import com.example.data.model.UserProfile
import com.example.data.repository.WalletRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab {
    WALLET,
    GAMES,
    HISTORY,
    PROFILE
}

enum class ActiveGame {
    NONE,
    LUDO,
    WORD_TASK,
    BALL_GAME
}

class WalletViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = WalletRepository(database.userDao(), database.transactionDao())

    val userProfile: StateFlow<UserProfile?> = repository.userProfile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val transactions: StateFlow<List<TransactionRecord>> = repository.allTransactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _currentTab = MutableStateFlow(MainTab.WALLET)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _activeGame = MutableStateFlow(ActiveGame.NONE)
    val activeGame: StateFlow<ActiveGame> = _activeGame.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Dialog controls
    private val _showDepositModal = MutableStateFlow(false)
    val showDepositModal: StateFlow<Boolean> = _showDepositModal.asStateFlow()

    private val _showWithdrawModal = MutableStateFlow(false)
    val showWithdrawModal: StateFlow<Boolean> = _showWithdrawModal.asStateFlow()

    private val _showSecurityModal = MutableStateFlow(false)
    val showSecurityModal: StateFlow<Boolean> = _showSecurityModal.asStateFlow()

    private val _showCustomerServiceModal = MutableStateFlow(false)
    val showCustomerServiceModal: StateFlow<Boolean> = _showCustomerServiceModal.asStateFlow()

    private val _showShareModal = MutableStateFlow(false)
    val showShareModal: StateFlow<Boolean> = _showShareModal.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultUser()
        }
    }

    fun setTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun openGame(game: ActiveGame) {
        if (userProfile.value?.isLoggedIn != true) {
            _errorMessage.value = "গেমে প্রবেশ করতে ও টাকা জিততে প্রথমে একাউন্টে লগইন করুন!"
            return
        }
        _activeGame.value = game
    }

    fun closeGame() {
        _activeGame.value = ActiveGame.NONE
    }

    fun toggleDepositModal(show: Boolean) {
        _showDepositModal.value = show
    }

    fun toggleWithdrawModal(show: Boolean) {
        _showWithdrawModal.value = show
    }

    fun toggleSecurityModal(show: Boolean) {
        _showSecurityModal.value = show
    }

    fun toggleCustomerServiceModal(show: Boolean) {
        _showCustomerServiceModal.value = show
    }

    fun toggleShareModal(show: Boolean) {
        _showShareModal.value = show
    }

    fun claimLoyaltyReward() {
        viewModelScope.launch {
            val res = repository.claimLoyaltyReward()
            res.fold(
                onSuccess = { amount ->
                    _statusMessage.value = "অভিনন্দন! ২-৩ দিনের ফ্রি উপস্থিতি উপহার হিসেবে ৳${amount.toInt()} আপনার ওয়ালেটে জমা হয়েছে!"
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "উপহার ক্লেইম করা সম্ভব হয়নি"
                }
            )
        }
    }

    fun setGender(gender: String) {
        viewModelScope.launch {
            repository.setGender(gender)
        }
    }

    fun clearMessages() {
        _statusMessage.value = null
        _errorMessage.value = null
    }

    fun performDeposit(
        amount: Double,
        method: String,
        trxId: String,
        senderNumber: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.depositMoney(amount, method, trxId, senderNumber)
            res.fold(
                onSuccess = {
                    _statusMessage.value = "৳${amount.toInt()} সফলভাবে আপনার ওয়ালেটে অটো অ্যাড হয়েছে!"
                    _showDepositModal.value = false
                    onSuccess()
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "ডিপোজিট ব্যর্থ হয়েছে"
                }
            )
        }
    }

    fun performWithdraw(
        amount: Double,
        method: String,
        targetNumber: String,
        twoFactorPin: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.withdrawMoney(amount, method, targetNumber, twoFactorPin)
            res.fold(
                onSuccess = {
                    _statusMessage.value = "৳${amount.toInt()} উইথড্র আবেদন সফল! দ্রুত $method একাউন্টে পৌঁছাবে।"
                    _showWithdrawModal.value = false
                    onSuccess()
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "উইথড্র ব্যর্থ হয়েছে"
                }
            )
        }
    }

    fun submitGameBetResult(
        gameName: String,
        betAmount: Double,
        isWin: Boolean,
        onComplete: (Boolean, Double) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.applyGameResult(gameName, betAmount, isWin)
            res.fold(
                onSuccess = { netResult ->
                    if (isWin) {
                        _statusMessage.value = "অভিনন্দন! আপনি জিতেছেন ৳${"%.1f".format(netResult)} (ডাবল + ১% বোনাস)!"
                    } else {
                        _errorMessage.value = "আপনি হেরে গেছেন। বাজি কয়েন ৳${betAmount.toInt()} কেটে নেওয়া হয়েছে।"
                    }
                    onComplete(isWin, netResult)
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "গেম সম্পন্ন করা সম্ভব হয়নি"
                    onComplete(false, 0.0)
                }
            )
        }
    }

    fun updateProfile(
        name: String,
        phone: String,
        pin: String,
        twoFactorPin: String,
        twoFactorEnabled: Boolean,
        gender: String = "MALE"
    ) {
        viewModelScope.launch {
            val res = repository.updateProfile(name, phone, pin, twoFactorPin, twoFactorEnabled, gender)
            res.fold(
                onSuccess = {
                    _statusMessage.value = "প্রোফাইল ও সিকিউরিটি সফলভাবে আপডেট হয়েছে!"
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "আপডেট ব্যর্থ হয়েছে"
                }
            )
        }
    }

    fun loginOrRegister(name: String, phone: String, pin: String, gender: String = "MALE") {
        viewModelScope.launch {
            val res = repository.loginOrRegister(name, phone, pin, gender)
            res.fold(
                onSuccess = {
                    _statusMessage.value = "স্বাগতম ${it.name}! লগইন সফল।"
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "লগইন ব্যর্থ হয়েছে"
                }
            )
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _statusMessage.value = "লগআউট সফল হয়েছে"
        }
    }
}
