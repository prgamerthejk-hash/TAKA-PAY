package com.example.ui.screens.games

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class WritingTaskItem(
    val title: String,
    val prompt: String,
    val expectedAnswer: String,
    val hint: String
)

@Composable
fun WordTaskGameScreen(
    user: UserProfile?,
    onBack: () -> Unit,
    onSubmitBetResult: (gameName: String, bet: Double, isWin: Boolean, onComplete: (Boolean, Double) -> Unit) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var betAmount by remember { mutableStateOf(50.0) } // Minimum 50 BDT
    var taskIndex by remember { mutableStateOf(0) }
    var userInput by remember { mutableStateOf("") }
    var timeLeft by remember { mutableStateOf(25) }
    var isTimerActive by remember { mutableStateOf(false) }
    var gameStarted by remember { mutableStateOf(false) }
    var showResultDialog by remember { mutableStateOf(false) }
    var isWinResult by remember { mutableStateOf(false) }
    var payoutAmount by remember { mutableStateOf(0.0) }

    val taskPool = remember {
        listOf(
            WritingTaskItem(
                title = "টাস্ক ১: দ্রুত লেখা চ্যালেঞ্জ",
                prompt = "আমার সোনার বাংলা আমি তোমায় ভালোবাসি",
                expectedAnswer = "আমার সোনার বাংলা আমি তোমায় ভালোবাসি",
                hint = "উপরে লেখা লাইনটি হুবহু নিচের বক্সে লিখুন"
            ),
            WritingTaskItem(
                title = "টাস্ক ২: সাধারণ জ্ঞান",
                prompt = "বাংলাদেশের রাজধানী শহরের নাম কী?",
                expectedAnswer = "ঢাকা",
                hint = "উত্তরটি বাংলায় সংক্ষেপে লিখুন"
            ),
            WritingTaskItem(
                title = "টাস্ক ৩: জাতীয় প্রতীক",
                prompt = "বাংলাদেশের জাতীয় পাখির নাম কী?",
                expectedAnswer = "দোয়েল",
                hint = "উত্তরটি বাংলায় এক শব্দে লিখুন (দোয়েল/দোয়েল)"
            ),
            WritingTaskItem(
                title = "টাস্ক ৪: টাইপিং টাস্ক",
                prompt = "ডিজিটাল ওয়ালেট নিরাপত্তা ও সুরক্ষা",
                expectedAnswer = "ডিজিটাল ওয়ালেট নিরাপত্তা ও সুরক্ষা",
                hint = "উপরে প্রদর্শিত বাক্যটি নির্ভুলভাবে টাইপ করুন"
            ),
            WritingTaskItem(
                title = "টাস্ক ৫: সাধারণ জ্ঞান",
                prompt = "সূর্য কোন দিকে উদিত হয়?",
                expectedAnswer = "পূর্ব",
                hint = "দিকটির নাম লিখুন (যেমন: পূর্ব)"
            ),
            WritingTaskItem(
                title = "টাস্ক ৬: লুডু নিয়মাবলী",
                prompt = "লুডু খেলায় ডাইসের সর্বোচ্চ সংখ্যা কত?",
                expectedAnswer = "৬",
                hint = "সংখ্যাটি লিখুন (যেমন: ৬ বা 6)"
            ),
            WritingTaskItem(
                title = "টাস্ক ৭: দেশাত্ববোধক বাক্য",
                prompt = "বাংলা আমার অহংকার",
                expectedAnswer = "বাংলা আমার অহংকার",
                hint = "হুবহু বাংলায় লিখে সাবমিট করুন"
            )
        )
    }

    val currentTask = taskPool[taskIndex % taskPool.size]

    // Countdown Timer
    LaunchedEffect(isTimerActive, timeLeft) {
        if (isTimerActive && timeLeft > 0) {
            delay(1000)
            timeLeft -= 1
        } else if (isTimerActive && timeLeft <= 0) {
            // Time out -> Player loses!
            isTimerActive = false
            gameStarted = false
            isWinResult = false
            onSubmitBetResult("লেখালেখি টাস্ক", betAmount, false) { won, payout ->
                payoutAmount = payout
                showResultDialog = true
            }
        }
    }

    fun startTask() {
        if ((user?.balance ?: 0.0) < betAmount) return
        userInput = ""
        timeLeft = 25
        isTimerActive = true
        gameStarted = true
    }

    fun checkAndSubmitAnswer() {
        if (!gameStarted || !isTimerActive) return
        isTimerActive = false
        gameStarted = false

        val cleanUser = userInput.trim().replace(" ", "").lowercase()
        val cleanExpected = currentTask.expectedAnswer.trim().replace(" ", "").lowercase()

        // Flexible match for Bengali variants
        val isCorrect = cleanUser == cleanExpected ||
                (cleanExpected == "ঢাকা" && cleanUser.contains("ঢাকা")) ||
                (cleanExpected.contains("দোয়েল") && (cleanUser.contains("দোয়েল") || cleanUser.contains("দোয়েল"))) ||
                (cleanExpected == "পূর্ব" && cleanUser.contains("পূর্ব")) ||
                (cleanExpected == "৬" && (cleanUser == "৬" || cleanUser == "6" || cleanUser.contains("ছয়")))

        isWinResult = isCorrect
        onSubmitBetResult("লেখালেখি টাস্ক", betAmount, isCorrect) { won, payout ->
            payoutAmount = payout
            showResultDialog = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("word_task_game_screen")
    ) {
        // Navigation Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "✍️ লেখালেখি টাস্ক গেম",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "নির্ভুল লিখে উত্তর দিন • ৫০৳ দিয়ে ১০০৳ + ১% বোনাস",
                    fontSize = 11.sp,
                    color = GoldenYellow,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = EmeraldGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "৳${(user?.balance ?: 0.0).toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bet Selector
        if (!gameStarted) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "বাজি নির্বাচন করুন (কমপক্ষে ৫০৳):",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(50.0, 100.0, 200.0).forEach { amt ->
                            Button(
                                onClick = { betAmount = amt },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (betAmount == amt) EmeraldGreen else Color(0xFF334155)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("৳${amt.toInt()}", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { startTask() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("start_word_task_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                        shape = RoundedCornerShape(14.dp),
                        enabled = (user?.balance ?: 0.0) >= betAmount
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if ((user?.balance ?: 0.0) >= betAmount) "টাস্ক শুরু করুন (৳${betAmount.toInt()})" else "পর্যাপ্ত ব্যালেন্স নেই (ডিপোজিট করুন)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Task Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentTask.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NagadOrange
                    )

                    // Timer Pill
                    Surface(
                        color = if (timeLeft < 10) CrimsonRed.copy(alpha = 0.2f) else EmeraldGreen.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = if (timeLeft < 10) CrimsonRed else EmeraldGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${timeLeft}s",
                                fontWeight = FontWeight.ExtraBold,
                                color = if (timeLeft < 10) CrimsonRed else EmeraldGreen
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Prompt Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, BkashPink.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "প্রশ্ন / লেখা টাস্ক:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = currentTask.prompt,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "নির্দেশনা: ${currentTask.hint}",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Input Field
                OutlinedTextField(
                    value = userInput,
                    onValueChange = { userInput = it },
                    label = { Text("আপনার উত্তর এখানে লিখুন") },
                    placeholder = { Text("এখানে লিখুন...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_answer_input"),
                    shape = RoundedCornerShape(12.dp),
                    enabled = gameStarted && isTimerActive
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (gameStarted) {
                    Button(
                        onClick = { checkAndSubmitAnswer() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_task_answer_btn"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                        enabled = userInput.isNotBlank() && isTimerActive
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "উত্তর সাবমিট করুন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            taskIndex = (taskIndex + 1) % taskPool.size
                            userInput = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("অন্য টাস্ক দেখুন")
                    }
                }
            }
        }
    }

    // Result Dialog
    if (showResultDialog) {
        AlertDialog(
            onDismissRequest = { showResultDialog = false },
            title = {
                Text(
                    text = if (isWinResult) "🎉 দুর্দান্ত! সঠিক উত্তর!" else "❌ ভুল উত্তর বা সময় শেষ!",
                    fontWeight = FontWeight.Bold,
                    color = if (isWinResult) EmeraldGreen else CrimsonRed
                )
            },
            text = {
                Column {
                    Text(
                        text = if (isWinResult) {
                            "আপনি সঠিকভাবে লেখা টাস্ক সম্পন্ন করেছেন! একাউন্টে ৳${payoutAmount.toInt()} টাকা যুক্ত হয়েছে (৫০৳ দিয়ে ১০০৳ + ১% বোনাস)!"
                        } else {
                            "সঠিক উত্তর ছিল: '${currentTask.expectedAnswer}'। ভুল উত্তরের কারণে বাজি কয়েন ৳${betAmount.toInt()} কেটে নেওয়া হয়েছে।"
                        },
                        fontSize = 14.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultDialog = false
                        taskIndex = (taskIndex + 1) % taskPool.size
                        userInput = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isWinResult) EmeraldGreen else NagadOrange)
                ) {
                    Text("পরের টাস্ক খেলুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResultDialog = false
                    onBack()
                }) {
                    Text("ওয়ালেটে ফিরুন")
                }
            }
        )
    }
}
