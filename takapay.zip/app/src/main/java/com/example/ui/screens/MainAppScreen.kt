package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AppInstallShareDialog
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.games.BallGameScreen
import com.example.ui.screens.games.GamesHubScreen
import com.example.ui.screens.games.LudoGameScreen
import com.example.ui.screens.games.WordTaskGameScreen
import com.example.ui.screens.history.TransactionHistoryScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.wallet.CustomerServiceDialog
import com.example.ui.screens.wallet.DepositDialog
import com.example.ui.screens.wallet.SecurityDetailsDialog
import com.example.ui.screens.wallet.WalletHomeScreen
import com.example.ui.screens.wallet.WithdrawDialog
import com.example.viewmodel.ActiveGame
import com.example.viewmodel.MainTab
import com.example.viewmodel.WalletViewModel

@Composable
fun MainAppScreen(
    viewModel: WalletViewModel = viewModel()
) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val activeGame by viewModel.activeGame.collectAsStateWithLifecycle()

    val showDepositModal by viewModel.showDepositModal.collectAsStateWithLifecycle()
    val showWithdrawModal by viewModel.showWithdrawModal.collectAsStateWithLifecycle()
    val showSecurityModal by viewModel.showSecurityModal.collectAsStateWithLifecycle()
    val showCustomerServiceModal by viewModel.showCustomerServiceModal.collectAsStateWithLifecycle()
    val showShareModal by viewModel.showShareModal.collectAsStateWithLifecycle()

    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    // Check if user is logged in
    if (userProfile != null && !userProfile!!.isLoggedIn) {
        AuthScreen(
            onLoginSuccess = { name, phone, pin, gender ->
                viewModel.loginOrRegister(name, phone, pin, gender)
            }
        )
        return
    }

    // Full screen game overlay if a game is active
    when (activeGame) {
        ActiveGame.LUDO -> {
            LudoGameScreen(
                user = userProfile,
                onBack = { viewModel.closeGame() },
                onSubmitBetResult = { gameName, bet, isWin, onComplete ->
                    viewModel.submitGameBetResult(gameName, bet, isWin, onComplete)
                }
            )
            return
        }
        ActiveGame.WORD_TASK -> {
            WordTaskGameScreen(
                user = userProfile,
                onBack = { viewModel.closeGame() },
                onSubmitBetResult = { gameName, bet, isWin, onComplete ->
                    viewModel.submitGameBetResult(gameName, bet, isWin, onComplete)
                }
            )
            return
        }
        ActiveGame.BALL_GAME -> {
            BallGameScreen(
                user = userProfile,
                onBack = { viewModel.closeGame() },
                onSubmitBetResult = { gameName, bet, isWin, onComplete ->
                    viewModel.submitGameBetResult(gameName, bet, isWin, onComplete)
                }
            )
            return
        }
        ActiveGame.NONE -> {
            // Regular tab navigation layout
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .testTag("bottom_nav_bar")
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = currentTab == MainTab.WALLET,
                    onClick = { viewModel.setTab(MainTab.WALLET) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.WALLET) Icons.Default.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet,
                            contentDescription = "Wallet"
                        )
                    },
                    label = { Text("ওয়ালেট") },
                    modifier = Modifier.testTag("tab_wallet")
                )

                NavigationBarItem(
                    selected = currentTab == MainTab.GAMES,
                    onClick = { viewModel.setTab(MainTab.GAMES) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.GAMES) Icons.Default.SportsEsports else Icons.Outlined.SportsEsports,
                            contentDescription = "Games"
                        )
                    },
                    label = { Text("৩টি গেম") },
                    modifier = Modifier.testTag("tab_games")
                )

                NavigationBarItem(
                    selected = currentTab == MainTab.HISTORY,
                    onClick = { viewModel.setTab(MainTab.HISTORY) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.HISTORY) Icons.Default.ReceiptLong else Icons.Outlined.ReceiptLong,
                            contentDescription = "History"
                        )
                    },
                    label = { Text("লেনদেন") },
                    modifier = Modifier.testTag("tab_history")
                )

                NavigationBarItem(
                    selected = currentTab == MainTab.PROFILE,
                    onClick = { viewModel.setTab(MainTab.PROFILE) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == MainTab.PROFILE) Icons.Default.Person else Icons.Outlined.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = { Text("প্রোফাইল") },
                    modifier = Modifier.testTag("tab_profile")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MainTab.WALLET -> {
                    WalletHomeScreen(
                        user = userProfile,
                        transactions = transactions,
                        onDepositClick = { viewModel.toggleDepositModal(true) },
                        onWithdrawClick = { viewModel.toggleWithdrawModal(true) },
                        onOpenSecurity = { viewModel.toggleSecurityModal(true) },
                        onOpenCustomerService = { viewModel.toggleCustomerServiceModal(true) },
                        onOpenShareModal = { viewModel.toggleShareModal(true) },
                        onClaimReward = { viewModel.claimLoyaltyReward() },
                        onNavigateTab = { tab -> viewModel.setTab(tab) },
                        onPlayGame = { game -> viewModel.openGame(game) }
                    )
                }
                MainTab.GAMES -> {
                    GamesHubScreen(
                        user = userProfile,
                        onSelectGame = { game -> viewModel.openGame(game) }
                    )
                }
                MainTab.HISTORY -> {
                    TransactionHistoryScreen(
                        transactions = transactions
                    )
                }
                MainTab.PROFILE -> {
                    ProfileScreen(
                        user = userProfile,
                        onUpdateProfile = { name, phone, pin, twoFactorPin, twoFactorEnabled, gender ->
                            viewModel.updateProfile(name, phone, pin, twoFactorPin, twoFactorEnabled, gender)
                        },
                        onSetGender = { gender -> viewModel.setGender(gender) },
                        onOpenShare = { viewModel.toggleShareModal(true) },
                        onClaimReward = { viewModel.claimLoyaltyReward() },
                        onLogout = { viewModel.logout() }
                    )
                }
            }
        }
    }

    // App Install & Share Modal (01843840404)
    if (showShareModal) {
        AppInstallShareDialog(
            onDismiss = { viewModel.toggleShareModal(false) }
        )
    }

    // Customer Service Dialog Modal
    if (showCustomerServiceModal) {
        CustomerServiceDialog(
            onDismiss = { viewModel.toggleCustomerServiceModal(false) }
        )
    }

    // Deposit Dialog Modal
    if (showDepositModal) {
        DepositDialog(
            onDismiss = { viewModel.toggleDepositModal(false) },
            onConfirmDeposit = { amount, method, trxId, senderNumber ->
                viewModel.performDeposit(amount, method, trxId, senderNumber) {}
            }
        )
    }

    // Withdraw Dialog Modal
    if (showWithdrawModal) {
        WithdrawDialog(
            user = userProfile,
            onDismiss = { viewModel.toggleWithdrawModal(false) },
            onConfirmWithdraw = { amount, method, targetNumber, twoFactorPin ->
                viewModel.performWithdraw(amount, method, targetNumber, twoFactorPin) {}
            }
        )
    }

    // Security Details Modal
    if (showSecurityModal) {
        SecurityDetailsDialog(
            user = userProfile,
            onDismiss = { viewModel.toggleSecurityModal(false) }
        )
    }
}
