package com.example.ui.screens.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.*
import com.example.viewmodel.ActiveGame

@Composable
fun GamesHubScreen(
    user: UserProfile?,
    onSelectGame: (ActiveGame) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("games_hub_screen")
    ) {
        // Hub Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                        )
                    )
                    .border(1.dp, Brush.linearGradient(listOf(BkashPink, NagadOrange)), RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎮 ৩টি আকর্ষণীয় গেম জোন",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Surface(
                            color = GoldenYellow.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "১০০% + ১% বোনাস",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldenYellow
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "যেকোনো খেলায় অংশ নিন (কমপক্ষে ৫০৳ বাজি)। জিতলে ৫০৳ দিয়ে ১০০৳ এবং একাউন্টে আরও ১% অতিরিক্ত বোনাস যোগ হবে! হারলে বাজি কয়েন কাটা হবে।",
                        fontSize = 13.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "খেলার তালিকা (৩টি গেম)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Game 1: Ludo
        GameCardItem(
            title = "১. লুডু ডাইস অ্যারেনা (Ludo Game)",
            subtitle = "স্মার্ট AI রোবটের সাথে রেস ট্র্যাক। ডাইস রোল করে ১২ ধাপে সবার আগে হোমে পৌঁছান!",
            badge = "মিনিমাম ৫০৳",
            icon = Icons.Default.Casino,
            accentColor = BkashPink,
            testTag = "play_ludo_card",
            onClick = { onSelectGame(ActiveGame.LUDO) }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Game 2: Word Writing Task
        GameCardItem(
            title = "২. লেখালেখি টাস্ক গেম (Word Task)",
            subtitle = "প্রদর্শিত বাংলা বাক্য ও কুইজ প্রশ্ন দেখে সঠিক উত্তর লিখে সাবমিট করুন ২৫ সেকেন্ডে!",
            badge = "মিনিমাম ৫০৳",
            icon = Icons.Default.EditNote,
            accentColor = NagadOrange,
            testTag = "play_word_task_card",
            onClick = { onSelectGame(ActiveGame.WORD_TASK) }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Game 3: Ball Game
        GameCardItem(
            title = "৩. গোল্ডেন বল ক্যাচ (Ball Game)",
            subtitle = "প্যাডেল দিয়ে উপর থেকে পড়া ৮টি সোনার বল সংগ্রহ করুন ও লাল বোমা এড়িয়ে চলুন!",
            badge = "মিনিমাম ৫০৳",
            icon = Icons.Default.SportsBasketball,
            accentColor = EmeraldGreen,
            testTag = "play_ball_game_card",
            onClick = { onSelectGame(ActiveGame.BALL_GAME) }
        )

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun GameCardItem(
    title: String,
    subtitle: String,
    badge: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = accentColor.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = badge,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.Default.PlayCircleFilled,
                contentDescription = "Play",
                tint = accentColor,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}
