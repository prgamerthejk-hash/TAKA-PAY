package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Male
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BkashPink
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenYellow

@Composable
fun CartoonBoyAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    val skinColor = Color(0xFFFFDBAC)
    val hairColor = Color(0xFF2D1E12)
    val capColor = Color(0xFF1E88E5)
    val hoodieColor = Color(0xFF0D47A1)
    val eyeColor = Color(0xFF1F2937)
    val blushColor = Color(0xFFFFAB91).copy(alpha = 0.5f)

    Box(
        modifier = modifier
            .size(size)
            .shadow(4.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFFE3F2FD), Color(0xFF90CAF9))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height

            // Hoodie / Shoulders
            drawRoundRect(
                color = hoodieColor,
                topLeft = Offset(w * 0.15f, h * 0.72f),
                size = Size(w * 0.7f, h * 0.35f),
                cornerRadius = CornerRadius(w * 0.2f, w * 0.2f)
            )

            // Inner shirt collar
            drawCircle(
                color = Color.White,
                radius = w * 0.14f,
                center = Offset(w * 0.5f, h * 0.78f)
            )

            // Neck
            drawRect(
                color = skinColor,
                topLeft = Offset(w * 0.42f, h * 0.58f),
                size = Size(w * 0.16f, h * 0.16f)
            )

            // Ears
            drawCircle(color = skinColor, radius = w * 0.08f, center = Offset(w * 0.24f, h * 0.48f))
            drawCircle(color = skinColor, radius = w * 0.08f, center = Offset(w * 0.76f, h * 0.48f))

            // Face
            drawRoundRect(
                color = skinColor,
                topLeft = Offset(w * 0.25f, h * 0.28f),
                size = Size(w * 0.5f, h * 0.45f),
                cornerRadius = CornerRadius(w * 0.22f, w * 0.22f)
            )

            // Cool Cap / Hair
            val capPath = Path().apply {
                moveTo(w * 0.22f, h * 0.38f)
                cubicTo(w * 0.22f, h * 0.12f, w * 0.78f, h * 0.12f, w * 0.78f, h * 0.38f)
                close()
            }
            drawPath(capPath, color = capColor)

            // Cap Visor
            drawRoundRect(
                color = Color(0xFF1565C0),
                topLeft = Offset(w * 0.2f, h * 0.34f),
                size = Size(w * 0.6f, h * 0.1f),
                cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
            )

            // Front Hair bangs peeking out
            drawCircle(color = hairColor, radius = w * 0.06f, center = Offset(w * 0.35f, h * 0.41f))
            drawCircle(color = hairColor, radius = w * 0.07f, center = Offset(w * 0.46f, h * 0.42f))
            drawCircle(color = hairColor, radius = w * 0.06f, center = Offset(w * 0.58f, h * 0.41f))

            // Eyebrows
            drawLine(
                color = hairColor,
                start = Offset(w * 0.34f, h * 0.44f),
                end = Offset(w * 0.44f, h * 0.45f),
                strokeWidth = w * 0.035f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = hairColor,
                start = Offset(w * 0.56f, h * 0.45f),
                end = Offset(w * 0.66f, h * 0.44f),
                strokeWidth = w * 0.035f,
                cap = StrokeCap.Round
            )

            // Eyes (sparkling cartoon boy eyes)
            drawCircle(color = eyeColor, radius = w * 0.05f, center = Offset(w * 0.39f, h * 0.51f))
            drawCircle(color = eyeColor, radius = w * 0.05f, center = Offset(w * 0.61f, h * 0.51f))
            // Eye sparkles
            drawCircle(color = Color.White, radius = w * 0.018f, center = Offset(w * 0.38f, h * 0.50f))
            drawCircle(color = Color.White, radius = w * 0.018f, center = Offset(w * 0.60f, h * 0.50f))

            // Cheerful blush
            drawCircle(color = blushColor, radius = w * 0.045f, center = Offset(w * 0.32f, h * 0.56f))
            drawCircle(color = blushColor, radius = w * 0.045f, center = Offset(w * 0.68f, h * 0.56f))

            // Confident friendly smile
            val smilePath = Path().apply {
                moveTo(w * 0.42f, h * 0.60f)
                quadraticBezierTo(w * 0.5f, h * 0.67f, w * 0.58f, h * 0.60f)
            }
            drawPath(
                path = smilePath,
                color = Color(0xFFC2185B),
                style = Stroke(width = w * 0.04f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun CartoonGirlAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    val skinColor = Color(0xFFFFE0BD)
    val hairColor = Color(0xFF3E2723)
    val dressColor = Color(0xFFE91E63)
    val ribbonColor = Color(0xFFFF4081)
    val eyeColor = Color(0xFF1F2937)
    val blushColor = Color(0xFFFF80AB).copy(alpha = 0.6f)

    Box(
        modifier = modifier
            .size(size)
            .shadow(4.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFFFCE4EC), Color(0xFFF8BBD0))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height

            // Long Back Hair
            drawRoundRect(
                color = hairColor,
                topLeft = Offset(w * 0.16f, h * 0.22f),
                size = Size(w * 0.68f, h * 0.62f),
                cornerRadius = CornerRadius(w * 0.3f, w * 0.3f)
            )

            // Girl Dress / Shoulders
            drawRoundRect(
                color = dressColor,
                topLeft = Offset(w * 0.2f, h * 0.72f),
                size = Size(w * 0.6f, h * 0.35f),
                cornerRadius = CornerRadius(w * 0.2f, w * 0.2f)
            )

            // White lace collar
            drawCircle(
                color = Color(0xFFFFF0F5),
                radius = w * 0.12f,
                center = Offset(w * 0.5f, h * 0.77f)
            )

            // Neck
            drawRect(
                color = skinColor,
                topLeft = Offset(w * 0.43f, h * 0.58f),
                size = Size(w * 0.14f, h * 0.15f)
            )

            // Cute small pearl earrings
            drawCircle(color = GoldenYellow, radius = w * 0.035f, center = Offset(w * 0.25f, h * 0.52f))
            drawCircle(color = GoldenYellow, radius = w * 0.035f, center = Offset(w * 0.75f, h * 0.52f))

            // Face
            drawRoundRect(
                color = skinColor,
                topLeft = Offset(w * 0.27f, h * 0.28f),
                size = Size(w * 0.46f, h * 0.44f),
                cornerRadius = CornerRadius(w * 0.22f, w * 0.22f)
            )

            // Cute Front Bangs / Hair style
            val bangsPath = Path().apply {
                moveTo(w * 0.24f, h * 0.32f)
                cubicTo(w * 0.35f, h * 0.18f, w * 0.65f, h * 0.18f, w * 0.76f, h * 0.32f)
                cubicTo(w * 0.68f, h * 0.44f, w * 0.54f, h * 0.38f, w * 0.50f, h * 0.42f)
                cubicTo(w * 0.46f, h * 0.38f, w * 0.32f, h * 0.44f, w * 0.24f, h * 0.32f)
                close()
            }
            drawPath(bangsPath, color = hairColor)

            // Cute Hair Bow / Ribbon on top right
            drawCircle(color = ribbonColor, radius = w * 0.07f, center = Offset(w * 0.70f, h * 0.22f))
            drawCircle(color = ribbonColor, radius = w * 0.07f, center = Offset(w * 0.80f, h * 0.22f))
            drawCircle(color = GoldenYellow, radius = w * 0.04f, center = Offset(w * 0.75f, h * 0.22f))

            // Delicate arched eyebrows
            drawLine(
                color = hairColor,
                start = Offset(w * 0.34f, h * 0.44f),
                end = Offset(w * 0.44f, h * 0.43f),
                strokeWidth = w * 0.025f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = hairColor,
                start = Offset(w * 0.56f, h * 0.43f),
                end = Offset(w * 0.66f, h * 0.44f),
                strokeWidth = w * 0.025f,
                cap = StrokeCap.Round
            )

            // Big expressive cartoon girl eyes with eyelashes
            drawCircle(color = eyeColor, radius = w * 0.055f, center = Offset(w * 0.38f, h * 0.50f))
            drawCircle(color = eyeColor, radius = w * 0.055f, center = Offset(w * 0.62f, h * 0.50f))

            // Dual sparkles in eyes for anime/cartoon charm
            drawCircle(color = Color.White, radius = w * 0.022f, center = Offset(w * 0.37f, h * 0.485f))
            drawCircle(color = Color.White, radius = w * 0.012f, center = Offset(w * 0.40f, h * 0.515f))
            drawCircle(color = Color.White, radius = w * 0.022f, center = Offset(w * 0.61f, h * 0.485f))
            drawCircle(color = Color.White, radius = w * 0.012f, center = Offset(w * 0.64f, h * 0.515f))

            // Eyelashes
            drawLine(
                color = hairColor,
                start = Offset(w * 0.33f, h * 0.46f),
                end = Offset(w * 0.31f, h * 0.43f),
                strokeWidth = w * 0.02f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = hairColor,
                start = Offset(w * 0.67f, h * 0.46f),
                end = Offset(w * 0.69f, h * 0.43f),
                strokeWidth = w * 0.02f,
                cap = StrokeCap.Round
            )

            // Rosy sweet blush
            drawCircle(color = blushColor, radius = w * 0.05f, center = Offset(w * 0.33f, h * 0.56f))
            drawCircle(color = blushColor, radius = w * 0.05f, center = Offset(w * 0.67f, h * 0.56f))

            // Sweet gentle smile
            val girlSmilePath = Path().apply {
                moveTo(w * 0.43f, h * 0.60f)
                quadraticBezierTo(w * 0.5f, h * 0.66f, w * 0.57f, h * 0.60f)
            }
            drawPath(
                path = girlSmilePath,
                color = Color(0xFFD81B60),
                style = Stroke(width = w * 0.035f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun UserCartoonAvatar(
    gender: String?,
    size: Dp = 50.dp,
    modifier: Modifier = Modifier,
    borderStroke: BorderStroke? = BorderStroke(2.dp, GoldenYellow)
) {
    val isFemale = gender?.equals("FEMALE", ignoreCase = true) == true
    val ringColor = if (isFemale) BkashPink else ElectricBlue

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .border(
                border = borderStroke ?: BorderStroke(2.dp, ringColor),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isFemale) {
            CartoonGirlAvatar(size = size)
        } else {
            CartoonBoyAvatar(size = size)
        }
    }
}

@Composable
fun GenderSelectorCard(
    selectedGender: String,
    onGenderSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "কাটুন প্রোফাইল ছবি নির্বাচন করুন (ছেলে / মেয়ে):",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Boy Option
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onGenderSelected("MALE") }
                    .testTag("select_boy_avatar"),
                shape = RoundedCornerShape(16.dp),
                color = if (selectedGender == "MALE") ElectricBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    width = if (selectedGender == "MALE") 2.dp else 1.dp,
                    color = if (selectedGender == "MALE") ElectricBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CartoonBoyAvatar(size = 64.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Male,
                            contentDescription = null,
                            tint = ElectricBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ছেলে (Boy)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (selectedGender == "MALE") ElectricBlue else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (selectedGender == "MALE") {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "✓ নির্বাচিত",
                            fontSize = 11.sp,
                            color = EmeraldGreen,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            // Girl Option
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onGenderSelected("FEMALE") }
                    .testTag("select_girl_avatar"),
                shape = RoundedCornerShape(16.dp),
                color = if (selectedGender == "FEMALE") BkashPink.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    width = if (selectedGender == "FEMALE") 2.dp else 1.dp,
                    color = if (selectedGender == "FEMALE") BkashPink else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CartoonGirlAvatar(size = 64.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Female,
                            contentDescription = null,
                            tint = BkashPink,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "মেয়ে (Girl)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (selectedGender == "FEMALE") BkashPink else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (selectedGender == "FEMALE") {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "✓ নির্বাচিত",
                            fontSize = 11.sp,
                            color = EmeraldGreen,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}
