package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors
val PrimaryDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val CardDark = Color(0xFF1E293B)
val BorderDark = Color(0xFF334155)

// bKash & Nagad Signature Colors
val BkashPink = Color(0xFFE2136E)
val BkashPinkDark = Color(0xFFC00C5A)
val NagadOrange = Color(0xFFF7931E)
val NagadRed = Color(0xFFED1C24)

// Financial & Gaming Accents
val EmeraldGreen = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val GoldenYellow = Color(0xFFF59E0B)
val AmberGlow = Color(0xFFFBBF24)
val CrimsonRed = Color(0xFFEF4444)
val ElectricBlue = Color(0xFF3B82F6)

// Theme M3 Colors
val DarkPrimary = Color(0xFF10B981)
val DarkOnPrimary = Color(0xFF003822)
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF131B2E)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)

val LightPrimary = Color(0xFF059669)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFCBD5E1)
