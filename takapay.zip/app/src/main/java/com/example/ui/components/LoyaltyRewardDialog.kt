package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.UserProfile
import com.example.ui.theme.BkashPink
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenYellow
import com.example.ui.theme.NagadOrange

const val REWARD_INTERVAL_MS = 2 * 24 * 60 * 60 * 1000L // 2 days

@Composable
fun LoyaltyRewardCard(
    user: UserProfile?,
    onClaimReward: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lastClaim = user?.lastRewardClaimTime ?: 0L
    val now = remember { System.currentTimeMillis() }
    val timeDiff = now - lastClaim
    val isEligible = lastClaim == 0L || timeDiff >= REWARD_INTERVAL_MS

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("loyalty_reward_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF1B5E20), Color(0xFF004D40))
                    )
                )
                .border(1.5.dp, Brush.linearGradient(listOf(GoldenYellow, EmeraldGreen)), RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(GoldenYellow.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🎁", fontSize = 22.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "২-৩ দিন পর পর উপস্থিতি উপহার",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                            Text(
                                text = "প্রতি ২-৩ দিনে নিশ্চিত ২০ টাকা ফ্রি বোনাস!",
                                fontSize = 11.sp,
                                color = GoldenYellow
                            )
                        }
                    }

                    Surface(
                        color = GoldenYellow,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "+২০৳ ক্যাশ",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isEligible) {
                        "আপনার ২-৩ দিনের ফ্রি উপহার প্রস্তুত! এখনই ক্লেইম করে সরাসরি ওয়ালেটে ২০ টাকা যোগ করুন।"
                    } else {
                        val hoursLeft = ((REWARD_INTERVAL_MS - timeDiff) / (1000 * 60 * 60)).coerceAtLeast(1)
                        "আপনি সফলভাবে ২০৳ উপহার পেয়েছেন! পরবর্তী উপহার আনলক হবে প্রায় $hoursLeft ঘন্টা পর।"
                    },
                    fontSize = 12.sp,
                    color = Color(0xFFE0F2F1),
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onClaimReward,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .scale(if (isEligible) pulseScale else 1f)
                        .testTag("claim_loyalty_reward_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isEligible) GoldenYellow else Color(0xFF37474F),
                        contentColor = if (isEligible) Color.Black else Color.LightGray
                    )
                ) {
                    Icon(
                        imageVector = if (isEligible) Icons.Default.CardGiftcard else Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEligible) "এখনই দাবি করুন ২০৳ উপহার!" else "উপহার সফলভাবে গৃহীত (মোট ${(user?.rewardClaimCount ?: 0)} বার)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
