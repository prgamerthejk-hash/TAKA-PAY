package com.example.ui.screens.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.hypot
import kotlin.random.Random

data class FallingBall(
    var x: Float,
    var y: Float,
    val radius: Float,
    val speed: Float,
    val isHazard: Boolean = false,
    var isCollected: Boolean = false
)

@Composable
fun BallGameScreen(
    user: UserProfile?,
    onBack: () -> Unit,
    onSubmitBetResult: (gameName: String, bet: Double, isWin: Boolean, onComplete: (Boolean, Double) -> Unit) -> Unit
) {
    var betAmount by remember { mutableStateOf(50.0) }
    var score by remember { mutableStateOf(0) }
    var targetScore by remember { mutableStateOf(8) }
    var lives by remember { mutableStateOf(3) }
    var timeLeft by remember { mutableStateOf(25) }
    var isPlaying by remember { mutableStateOf(false) }
    var paddleX by remember { mutableStateOf(0.5f) } // normalized 0..1
    var showResultDialog by remember { mutableStateOf(false) }
    var isWinResult by remember { mutableStateOf(false) }
    var payoutAmount by remember { mutableStateOf(0.0) }

    val balls = remember { mutableStateListOf<FallingBall>() }

    fun resetGame() {
        score = 0
        lives = 3
        timeLeft = 25
        balls.clear()
        isPlaying = false
    }

    fun startGame() {
        if ((user?.balance ?: 0.0) < betAmount) return
        resetGame()
        isPlaying = true
    }

    // Main Game Loop
    LaunchedEffect(isPlaying) {
        if (!isPlaying) return@LaunchedEffect

        var tickCounter = 0
        while (isActive && isPlaying) {
            delay(30)
            tickCounter++

            // Timer update every 1 second (approx 33 ticks)
            if (tickCounter % 33 == 0) {
                timeLeft -= 1
                if (timeLeft <= 0) {
                    // Time up check
                    isPlaying = false
                    val won = score >= targetScore
                    isWinResult = won
                    onSubmitBetResult("বল গেম", betAmount, won) { w, payout ->
                        payoutAmount = payout
                        showResultDialog = true
                    }
                    break
                }
            }

            // Spawn balls occasionally
            if (tickCounter % 20 == 0 && balls.size < 7) {
                val isBomb = Random.nextFloat() < 0.25f
                balls.add(
                    FallingBall(
                        x = Random.nextFloat(),
                        y = -0.05f,
                        radius = if (isBomb) 22f else 26f,
                        speed = Random.nextFloat() * 0.012f + 0.008f,
                        isHazard = isBomb
                    )
                )
            }

            // Update ball positions & check collisions
            val iterator = balls.iterator()
            while (iterator.hasNext()) {
                val ball = iterator.next()
                ball.y += ball.speed

                // Check collision with paddle near bottom (y ~ 0.88f)
                val paddleY = 0.88f
                val paddleWidth = 0.26f

                if (ball.y in (paddleY - 0.04f)..(paddleY + 0.04f) && !ball.isCollected) {
                    val dist = kotlin.math.abs(ball.x - paddleX)
                    if (dist < (paddleWidth / 2f)) {
                        ball.isCollected = true
                        if (ball.isHazard) {
                            lives -= 1
                            if (lives <= 0) {
                                isPlaying = false
                                isWinResult = false
                                onSubmitBetResult("বল গেম", betAmount, false) { _, payout ->
                                    payoutAmount = payout
                                    showResultDialog = true
                                }
                                break
                            }
                        } else {
                            score += 1
                            if (score >= targetScore) {
                                isPlaying = false
                                isWinResult = true
                                onSubmitBetResult("বল গেম", betAmount, true) { _, payout ->
                                    payoutAmount = payout
                                    showResultDialog = true
                                }
                                break
                            }
                        }
                    }
                }

                // Remove balls that dropped past screen
                if (ball.y > 1.05f || ball.isCollected) {
                    iterator.remove()
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("ball_game_screen")
    ) {
        // Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "⚽ গোল্ডেন বল ক্যাচ গেম",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "৮টি বল ধরুন • ৫০৳ দিয়ে ১০০৳ + ১% বোনাস",
                    fontSize = 11.sp,
                    color = GoldenYellow,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = EmeraldGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "৳${(user?.balance ?: 0.0).toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Live Game Stats Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SportsBasketball, contentDescription = null, tint = GoldenYellow, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "সংগ্রহ: $score / $targetScore",
                        fontWeight = FontWeight.Bold,
                        color = GoldenYellow,
                        fontSize = 14.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Favorite, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "লাইফ: $lives",
                        fontWeight = FontWeight.Bold,
                        color = CrimsonRed,
                        fontSize = 14.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${timeLeft}s",
                        fontWeight = FontWeight.Bold,
                        color = EmeraldGreen,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Interactive Canvas Game Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF0F172A))
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val newNormalizedX = (change.position.x / size.width).coerceIn(0.12f, 0.88f)
                        paddleX = newNormalizedX
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        paddleX = (offset.x / size.width).coerceIn(0.12f, 0.88f)
                    }
                }
                .testTag("ball_canvas_box")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasW = size.width
                val canvasH = size.height

                // Draw falling balls
                balls.forEach { ball ->
                    val cx = ball.x * canvasW
                    val cy = ball.y * canvasH

                    if (ball.isHazard) {
                        // Hazard bomb (Red with cross)
                        drawCircle(
                            color = CrimsonRed,
                            radius = ball.radius,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = Color.Black,
                            radius = ball.radius * 0.4f,
                            center = Offset(cx, cy)
                        )
                    } else {
                        // Golden Coin / Ball
                        drawCircle(
                            color = GoldenYellow,
                            radius = ball.radius,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = AmberGlow,
                            radius = ball.radius * 0.7f,
                            center = Offset(cx, cy)
                        )
                    }
                }

                // Draw Paddle / Basket at bottom
                val pw = canvasW * 0.26f
                val ph = 24f
                val px = (paddleX * canvasW) - (pw / 2f)
                val py = canvasH * 0.88f

                drawRoundRect(
                    color = BkashPink,
                    topLeft = Offset(px, py),
                    size = Size(pw, ph),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
            }

            if (!isPlaying) {
                // Overlay for game start / bet select
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.65f)),
                    color = Color.Transparent
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "🏀 গোল্ডেন বল ক্যাচ",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "নিচের প্যাডেল ড্র্যাগ করে সোনার বলগুলো ধরুন। লাল বোমা এড়িয়ে চলুন!",
                            fontSize = 13.sp,
                            color = Color(0xFFCBD5E1),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(50.0, 100.0, 200.0).forEach { amt ->
                                Button(
                                    onClick = { betAmount = amt },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (betAmount == amt) EmeraldGreen else Color(0xFF334155)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("৳${amt.toInt()}", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = { startGame() },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .height(52.dp)
                                .testTag("start_ball_game_btn"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                            enabled = (user?.balance ?: 0.0) >= betAmount
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if ((user?.balance ?: 0.0) >= betAmount) "খেলা শুরু করুন (৳${betAmount.toInt()})" else "পর্যাপ্ত ব্যালেন্স নেই",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Result Dialog
    if (showResultDialog) {
        AlertDialog(
            onDismissRequest = { showResultDialog = false },
            title = {
                Text(
                    text = if (isWinResult) "🎉 অভিনন্দন! আপনি জিতেছেন!" else "❌ আপনি হেরে গেছেন!",
                    fontWeight = FontWeight.Bold,
                    color = if (isWinResult) EmeraldGreen else CrimsonRed
                )
            },
            text = {
                Column {
                    Text(
                        text = if (isWinResult) {
                            "আপনি সফলভাবে ৮টি বল সংগ্রহ করেছেন! আপনার ওয়ালেটে ৳${payoutAmount.toInt()} টাকা যোগ হয়েছে (৫০৳ দিয়ে খেলে ১০০৳ + ১% বোনাস)!"
                        } else {
                            "সময় শেষ বা বোমা বিস্ফোরণের কারণে আপনি হেরে গেছেন। বাজি কয়েন ৳${betAmount.toInt()} একাউন্ট থেকে কাটা হয়েছে।"
                        },
                        fontSize = 14.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultDialog = false
                        resetGame()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isWinResult) EmeraldGreen else NagadOrange)
                ) {
                    Text("আবার খেলুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResultDialog = false
                    onBack()
                }) {
                    Text("ওয়ালেটে ফিরুন")
                }
            }
        )
    }
}
