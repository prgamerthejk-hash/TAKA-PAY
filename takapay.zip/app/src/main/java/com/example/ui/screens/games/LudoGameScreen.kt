package com.example.ui.screens.games

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.components.UserCartoonAvatar
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Audio feedback generator for realistic Ludo clatter & movements
 */
object LudoSoundFX {
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (_: Exception) {}
    }

    fun playDiceRoll() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
        } catch (_: Exception) {}
    }

    fun playStep() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_DTMF_D, 40)
        } catch (_: Exception) {}
    }

    fun playSixBonus() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_PBX_L, 120)
        } catch (_: Exception) {}
    }

    fun playCapture() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 160)
        } catch (_: Exception) {}
    }

    fun playVictory() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_KEYPAD_VOLUME_KEY_LITE, 300)
        } catch (_: Exception) {}
    }
}

/**
 * Coordinate mapping for realistic authentic Ludo board path
 * 0: Base Yard (ঘর)
 * 1..15: Board perimeter path
 * 16..17: Colored Home Path (পাকা পথ)
 * 18: Center Home (বিজয়)
 */
data class BoardCoord(val col: Float, val row: Float)

// 15x15 Ludo Board coordinates (from 0 to 14)
val RED_PLAYER_PATH = listOf(
    BoardCoord(2.5f, 11.5f), // 0: Red Yard
    BoardCoord(6f, 13f),     // 1: Red Start Square (★ Safe)
    BoardCoord(6f, 12f),     // 2
    BoardCoord(6f, 11f),     // 3
    BoardCoord(6f, 10f),     // 4
    BoardCoord(6f, 9f),      // 5
    BoardCoord(5f, 8f),      // 6
    BoardCoord(3f, 8f),      // 7
    BoardCoord(1f, 8f),      // 8: Safe Star Square (★)
    BoardCoord(1f, 6f),      // 9
    BoardCoord(3f, 6f),      // 10
    BoardCoord(5f, 6f),      // 11
    BoardCoord(6f, 5f),      // 12
    BoardCoord(6f, 2f),      // 13: Top turn
    BoardCoord(7f, 1f),      // 14
    BoardCoord(8f, 2f),      // 15
    BoardCoord(7f, 11f),     // 16: Red Home Column (পাকা পথ ১)
    BoardCoord(7f, 10f),     // 17: Red Home Column (পাকা পথ ২)
    BoardCoord(7f, 7.5f)     // 18: Central Home (বিজয়)
)

val BOT_GREEN_PATH = listOf(
    BoardCoord(2.5f, 2.5f),  // 0: Green Yard
    BoardCoord(1f, 6f),      // 1: Green Start Square (★ Safe)
    BoardCoord(3f, 6f),      // 2
    BoardCoord(5f, 6f),      // 3
    BoardCoord(6f, 5f),      // 4
    BoardCoord(6f, 2f),      // 5
    BoardCoord(7f, 1f),      // 6
    BoardCoord(8f, 2f),      // 7
    BoardCoord(8f, 5f),      // 8: Safe Star Square (★)
    BoardCoord(9f, 6f),      // 9
    BoardCoord(11f, 6f),     // 10
    BoardCoord(13f, 6f),     // 11
    BoardCoord(13f, 8f),     // 12
    BoardCoord(11f, 8f),     // 13
    BoardCoord(9f, 8f),      // 14
    BoardCoord(8f, 9f),      // 15
    BoardCoord(3f, 7f),      // 16: Green Home Column (পাকা পথ ১)
    BoardCoord(5f, 7f),      // 17: Green Home Column (পাকা পথ ২)
    BoardCoord(7f, 7.5f)     // 18: Central Home (বিজয়)
)

// Safe positions where capture cannot occur
val SAFE_PATH_STEPS = setOf(1, 8)

@Composable
fun LudoGameScreen(
    user: UserProfile?,
    onBack: () -> Unit,
    onSubmitBetResult: (gameName: String, bet: Double, isWin: Boolean, onComplete: (Boolean, Double) -> Unit) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var betAmount by remember { mutableStateOf(50.0) } // Minimum 50 Taka
    var diceValue by remember { mutableStateOf(6) }
    var isRolling by remember { mutableStateOf(false) }

    // Positions (0 = Yard, 1..17 = Board steps, 18 = Home)
    var playerPos by remember { mutableStateOf(0) }
    var botPos by remember { mutableStateOf(0) }
    val maxSteps = 18

    var isPlayerTurn by remember { mutableStateOf(true) }
    var gameInProgress by remember { mutableStateOf(false) }
    var gameFinished by remember { mutableStateOf(false) }
    var playerWon by remember { mutableStateOf(false) }
    var commentaryText by remember { mutableStateOf("খেলার বাজি নির্বাচন করে 'লুডু শুরু করুন' চাপুন!") }
    var extraTurnEarned by remember { mutableStateOf(false) }

    var payoutResult by remember { mutableStateOf(0.0) }
    var showResultDialog by remember { mutableStateOf(false) }

    // Animated Dice rotation & scale
    val diceRotation by animateFloatAsState(
        targetValue = if (isRolling) 720f else 0f,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "dice_rot"
    )
    val diceScale by animateFloatAsState(
        targetValue = if (isRolling) 1.25f else 1.0f,
        animationSpec = tween(durationMillis = 250),
        label = "dice_scale"
    )

    fun resetGame() {
        playerPos = 0
        botPos = 0
        diceValue = 6
        isPlayerTurn = true
        gameFinished = false
        playerWon = false
        gameInProgress = false
        showResultDialog = false
        extraTurnEarned = false
        commentaryText = "বাজি নির্বাচন করুন ও লুডু শুরু করুন!"
    }

    fun startNewGame() {
        if ((user?.balance ?: 0.0) < betAmount) return
        resetGame()
        gameInProgress = true
        commentaryText = "লুডু খেলা শুরু! আপনার চাল - ডাইস রোল করুন 🎲"
    }

    fun executeBotTurn() {
        coroutineScope.launch {
            delay(800)
            isRolling = true
            LudoSoundFX.playDiceRoll()

            // Realistic tumbling
            repeat(5) {
                delay(80)
                diceValue = Random.nextInt(1, 7)
            }
            delay(100)
            val roll = Random.nextInt(1, 7)
            diceValue = roll
            isRolling = false

            // Bot logic
            var botBonus = false
            if (roll == 6) {
                LudoSoundFX.playSixBonus()
                botBonus = true
                if (botPos == 0) {
                    botPos = 1
                    commentaryText = "রোবট ছক্কা মেরে ঘুঁটি বোর্ডে বের করল! 🤖"
                } else {
                    botPos = (botPos + roll).coerceAtMost(maxSteps)
                    commentaryText = "রোবট ছক্কা মেরেছে! আরেকটি চাল পাবে!"
                }
            } else {
                LudoSoundFX.playStep()
                if (botPos == 0) {
                    commentaryText = "রোবট ছক্কা পায়নি ($roll)। ঘুঁটি বের করতে পারল না।"
                } else {
                    botPos = (botPos + roll).coerceAtMost(maxSteps)
                    commentaryText = "রোবট $roll ধাপে এগিয়ে গেল ($botPos/$maxSteps)"
                }
            }

            // Check if Bot captured Player
            if (botPos > 0 && botPos < maxSteps && botPos == playerPos && !SAFE_PATH_STEPS.contains(botPos)) {
                LudoSoundFX.playCapture()
                playerPos = 0
                commentaryText = "ওহ নো! রোবট আপনার ঘুঁটি কেটে দিয়েছে! আপনি আবার ঘরের মধ্যে! 💥"
                botBonus = true
            }

            // Check if Bot reached Home
            if (botPos >= maxSteps) {
                LudoSoundFX.playVictory()
                gameFinished = true
                gameInProgress = false
                playerWon = false
                onSubmitBetResult("লুডু গেম", betAmount, false) { won, payout ->
                    payoutResult = payout
                    showResultDialog = true
                }
            } else {
                if (botBonus) {
                    delay(1000)
                    executeBotTurn()
                } else {
                    isPlayerTurn = true
                    commentaryText = "আপনার চাল! ডাইস ছুঁড়ে মারুন 🎲"
                }
            }
        }
    }

    fun rollPlayerDice() {
        if (isRolling || !isPlayerTurn || gameFinished || !gameInProgress) return

        coroutineScope.launch {
            isRolling = true
            LudoSoundFX.playDiceRoll()

            // Realistic tumbling frames
            repeat(5) {
                delay(80)
                diceValue = Random.nextInt(1, 7)
            }
            delay(100)
            val roll = Random.nextInt(1, 7)
            diceValue = roll
            isRolling = false

            var playerGotBonus = false

            if (roll == 6) {
                LudoSoundFX.playSixBonus()
                playerGotBonus = true
                if (playerPos == 0) {
                    playerPos = 1
                    commentaryText = "🎉 ছক্কা! আপনার লাল ঘুঁটি বোর্ড অ্যারেনায় নেমেছে! বোনাস চাল নিন!"
                } else {
                    playerPos = (playerPos + roll).coerceAtMost(maxSteps)
                    commentaryText = "🎉 ছক্কা! ৬ ধাপ এগিয়েছেন! বোনাস চাল পেয়েছেন!"
                }
            } else {
                LudoSoundFX.playStep()
                if (playerPos == 0) {
                    commentaryText = "আপনি $roll পেয়েছেন। ঘুঁটি বের করতে ছক্কা (৬) প্রয়োজন!"
                } else {
                    playerPos = (playerPos + roll).coerceAtMost(maxSteps)
                    commentaryText = "আপনি $roll পেয়েছেন! এগিয়ে গেলেন ($playerPos/$maxSteps)"
                }
            }

            // Check if Player captured Bot
            if (playerPos > 0 && playerPos < maxSteps && playerPos == botPos && !SAFE_PATH_STEPS.contains(playerPos)) {
                LudoSoundFX.playCapture()
                botPos = 0
                commentaryText = "💥 কাটাকাটি! আপনি রোবটের ঘুঁটি খেয়ে ঘরে পাঠিয়ে দিয়েছেন! বোনাস চাল!"
                playerGotBonus = true
            }

            // Check if Player won
            if (playerPos >= maxSteps) {
                LudoSoundFX.playVictory()
                gameFinished = true
                gameInProgress = false
                playerWon = true
                onSubmitBetResult("লুডু গেম", betAmount, true) { won, payout ->
                    payoutResult = payout
                    showResultDialog = true
                }
            } else {
                if (playerGotBonus) {
                    extraTurnEarned = true
                    // Player rolls again!
                } else {
                    extraTurnEarned = false
                    isPlayerTurn = false
                    commentaryText = "রোবটের চাল... অপেক্ষা করুন 🤖"
                    executeBotTurn()
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .verticalScroll(rememberScrollState())
            .testTag("ludo_game_screen")
    ) {
        // Top Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "🎲 ক্লাসিক লুডু অ্যারেনা",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "কমপক্ষে ৫০৳ বাজি • জিতলে ১০০৳ + ১% বোনাস",
                    fontSize = 11.sp,
                    color = GoldenYellow,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = EmeraldGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "৳${(user?.balance ?: 0.0).toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Players Banner with Cartoon Avatars
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Player 1 (User with Cartoon Avatar)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (isPlayerTurn && gameInProgress) Color(0xFFDC2626).copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .border(
                        1.5.dp,
                        if (isPlayerTurn && gameInProgress) Color(0xFFDC2626) else Color.Transparent,
                        RoundedCornerShape(14.dp)
                    )
                    .padding(8.dp)
            ) {
                UserCartoonAvatar(gender = user?.gender, size = 36.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFDC2626))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = user?.name ?: "আপনি",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = if (playerPos == 0) "ঘরে (Yard)" else if (playerPos >= maxSteps) "হোম জয়ী 🏆" else "$playerPos/$maxSteps ধাপ",
                        fontSize = 10.sp,
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // VS Badge
            Surface(
                color = GoldenYellow.copy(alpha = 0.15f),
                shape = CircleShape,
                border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "VS",
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = GoldenYellow,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            // Player 2 (Robot AI)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (!isPlayerTurn && gameInProgress) Color(0xFF16A34A).copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .border(
                        1.5.dp,
                        if (!isPlayerTurn && gameInProgress) Color(0xFF16A34A) else Color.Transparent,
                        RoundedCornerShape(14.dp)
                    )
                    .padding(8.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "রোবট মাস্টার",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF16A34A))
                        )
                    }
                    Text(
                        text = if (botPos == 0) "ঘরে (Yard)" else if (botPos >= maxSteps) "হোম জয়ী 🏆" else "$botPos/$maxSteps ধাপ",
                        fontSize = 10.sp,
                        color = Color(0xFF16A34A),
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF16A34A).copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🤖", fontSize = 20.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Real-Time Commentary Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = if (commentaryText.contains("ছক্কা") || commentaryText.contains("কাটাকাটি"))
                GoldenYellow.copy(alpha = 0.2f)
            else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📢 ",
                    fontSize = 14.sp
                )
                Text(
                    text = commentaryText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // REALISTIC AUTHENTIC LUDO BOARD CANVAS
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(8.dp, RoundedCornerShape(20.dp))
                .testTag("realistic_ludo_board"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
            border = BorderStroke(4.dp, Color(0xFF78350F)) // Wooden outer frame
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Background Classic Ludo Board Grid & Quadrants
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRealisticLudoBoard(size)
                }

                // Interactive Overlaid Tokens (Pawns)
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val boardWidth = maxWidth
                    val boardHeight = maxHeight
                    val cellWidth = boardWidth / 15f
                    val cellHeight = boardHeight / 15f

                    // Red Pawn (Player)
                    val pCoord = RED_PLAYER_PATH[playerPos.coerceIn(0, RED_PLAYER_PATH.size - 1)]
                    val playerX = cellWidth * pCoord.col
                    val playerY = cellHeight * pCoord.row

                    // Green Pawn (Bot)
                    val bCoord = BOT_GREEN_PATH[botPos.coerceIn(0, BOT_GREEN_PATH.size - 1)]
                    val botX = cellWidth * bCoord.col
                    val botY = cellHeight * bCoord.row

                    // Draw Bot Token
                    Box(
                        modifier = Modifier
                            .offset(x = botX - 6.dp, y = botY - 6.dp)
                            .size(cellWidth * 1.5f)
                            .testTag("bot_ludo_token"),
                        contentAlignment = Alignment.Center
                    ) {
                        LudoPawnView(
                            color = Color(0xFF16A34A),
                            glowColor = Color(0xFF4ADE80),
                            label = "🤖",
                            isTurn = !isPlayerTurn && gameInProgress
                        )
                    }

                    // Draw Player Token
                    Box(
                        modifier = Modifier
                            .offset(x = playerX - 6.dp, y = playerY - 6.dp)
                            .size(cellWidth * 1.5f)
                            .clickable {
                                if (isPlayerTurn && !isRolling) rollPlayerDice()
                            }
                            .testTag("player_ludo_token"),
                        contentAlignment = Alignment.Center
                    ) {
                        LudoPawnView(
                            color = Color(0xFFDC2626),
                            glowColor = Color(0xFFF87171),
                            label = "👑",
                            isTurn = isPlayerTurn && gameInProgress
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Control Area: 3D Rolling Dice & Bet Controls
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // If game is NOT in progress: Bet Selector
                if (!gameInProgress) {
                    Text(
                        text = "বাজি নির্বাচন করুন (মিনিমাম ৫০৳):",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(50.0, 100.0, 200.0).forEach { amt ->
                            Button(
                                onClick = { betAmount = amt },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (betAmount == amt) EmeraldGreen else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "৳${amt.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (betAmount == amt) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = GoldenYellow.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = GoldenYellow, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "জিতলে পাবেন: ৳${(betAmount * 2 + betAmount * 0.01).toInt()} (ডাবল + ১% উপহার বোনাস)!",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldenYellow
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { startNewGame() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("start_ludo_game_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BkashPink),
                        shape = RoundedCornerShape(14.dp),
                        enabled = (user?.balance ?: 0.0) >= betAmount
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if ((user?.balance ?: 0.0) >= betAmount) "লুডু অ্যারেনায় নামুন (৳${betAmount.toInt()})" else "পর্যাপ্ত ব্যালেন্স নেই (ডিপোজিট করুন)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                } else {
                    // Active Game Controls & 3D Interactive Dice
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (isPlayerTurn) "আপনার চাল!" else "রোবটের চাল...",
                                fontWeight = FontWeight.Bold,
                                color = if (isPlayerTurn) Color(0xFFDC2626) else Color(0xFF16A34A),
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isPlayerTurn) "ডাইসে ট্যাপ করুন" else "রোবট চাল দিচ্ছে...",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // 3D Realistic Rolling Dice with Rotation and Bounce
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .scale(diceScale)
                                .rotate(diceRotation)
                                .shadow(10.dp, RoundedCornerShape(18.dp))
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFFFFFFFF), Color(0xFFF1F5F9), Color(0xFFE2E8F0))
                                    )
                                )
                                .border(
                                    3.dp,
                                    if (isPlayerTurn) Color(0xFFDC2626) else Color(0xFF16A34A),
                                    RoundedCornerShape(18.dp)
                                )
                                .clickable {
                                    if (isPlayerTurn && !isRolling) rollPlayerDice()
                                }
                                .testTag("ludo_dice_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            DiceDotsView(diceValue)
                        }

                        // Dice Roll Button
                        Button(
                            onClick = { rollPlayerDice() },
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("roll_dice_btn"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlayerTurn) Color(0xFFDC2626) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            enabled = isPlayerTurn && !isRolling && !gameFinished
                        ) {
                            Icon(Icons.Default.Casino, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPlayerTurn) "রোল 🎲" else "অপেক্ষা...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Victory/Loss Modal Dialog
    if (showResultDialog) {
        AlertDialog(
            onDismissRequest = { showResultDialog = false },
            title = {
                Text(
                    text = if (playerWon) "🎉 অভিনন্দন! আপনি জিতেছেন!" else "😢 আপনি হেরে গেছেন!",
                    fontWeight = FontWeight.Bold,
                    color = if (playerWon) EmeraldGreen else CrimsonRed
                )
            },
            text = {
                Column {
                    Text(
                        text = if (playerWon) {
                            "চমৎকার! আপনি রোবটকে হারিয়ে লুডু সেন্টারে বিজয়ী হয়েছেন! আপনার একাউন্টে ৳${payoutResult.toInt()} টাকা যোগ হয়েছে (বাজি ডাবল + ১% অতিরিক্ত বোনাস)!"
                        } else {
                            "রোবট আগে সেন্টারে পৌঁছে গেছে। বাজি ৳${betAmount.toInt()} একাউন্ট থেকে কর্তন হয়েছে। আবার চেষ্টা করুন!"
                        },
                        fontSize = 14.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultDialog = false
                        resetGame()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (playerWon) EmeraldGreen else NagadOrange)
                ) {
                    Text("আবার খেলুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showResultDialog = false
                    onBack()
                }) {
                    Text("ওয়ালেটে ফিরুন")
                }
            }
        )
    }
}

/**
 * 3D Ludo Pawn Component
 */
@Composable
fun LudoPawnView(
    color: Color,
    glowColor: Color,
    label: String,
    isTurn: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pawn_anim")
    val bounceOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isTurn) -6f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bounce"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.offset(y = bounceOffset.dp)
    ) {
        // 3D Glass/Plastic Pawn Head
        Box(
            modifier = Modifier
                .size(24.dp)
                .shadow(6.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(glowColor, color, Color.Black.copy(alpha = 0.6f)),
                        radius = 28f
                    )
                )
                .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(text = label, fontSize = 10.sp)
        }

        // Pawn Base
        Box(
            modifier = Modifier
                .width(18.dp)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFFD97706)) // Golden ring base
        )
    }
}

/**
 * Realistic 15x15 Classic Ludo Board Painter
 */
fun DrawScope.drawRealisticLudoBoard(size: Size) {
    val w = size.width
    val h = size.height
    val cellW = w / 15f
    val cellH = h / 15f

    val redColor = Color(0xFFDC2626)
    val greenColor = Color(0xFF16A34A)
    val yellowColor = Color(0xFFEAB308)
    val blueColor = Color(0xFF2563EB)
    val safeStarColor = Color(0xFFF59E0B)

    // 1. Draw 4 Home Yards (6x6 cells each)
    // Top-Left: Green Yard
    drawRect(greenColor, Offset(0f, 0f), Size(cellW * 6, cellH * 6))
    drawRoundRect(
        Color.White,
        Offset(cellW * 0.8f, cellH * 0.8f),
        Size(cellW * 4.4f, cellH * 4.4f),
        androidx.compose.ui.geometry.CornerRadius(16f, 16f)
    )
    // 4 Green Yard Token Circles
    listOf(
        Offset(cellW * 2f, cellH * 2f),
        Offset(cellW * 4f, cellH * 2f),
        Offset(cellW * 2f, cellH * 4f),
        Offset(cellW * 4f, cellH * 4f)
    ).forEach { center ->
        drawCircle(greenColor, radius = cellW * 0.7f, center = center)
        drawCircle(Color.White, radius = cellW * 0.35f, center = center)
    }

    // Top-Right: Yellow Yard
    drawRect(yellowColor, Offset(cellW * 9, 0f), Size(cellW * 6, cellH * 6))
    drawRoundRect(
        Color.White,
        Offset(cellW * 9.8f, cellH * 0.8f),
        Size(cellW * 4.4f, cellH * 4.4f),
        androidx.compose.ui.geometry.CornerRadius(16f, 16f)
    )
    listOf(
        Offset(cellW * 11f, cellH * 2f),
        Offset(cellW * 13f, cellH * 2f),
        Offset(cellW * 11f, cellH * 4f),
        Offset(cellW * 13f, cellH * 4f)
    ).forEach { center ->
        drawCircle(yellowColor, radius = cellW * 0.7f, center = center)
        drawCircle(Color.White, radius = cellW * 0.35f, center = center)
    }

    // Bottom-Left: Red Yard (Player)
    drawRect(redColor, Offset(0f, cellH * 9), Size(cellW * 6, cellH * 6))
    drawRoundRect(
        Color.White,
        Offset(cellW * 0.8f, cellH * 9.8f),
        Size(cellW * 4.4f, cellH * 4.4f),
        androidx.compose.ui.geometry.CornerRadius(16f, 16f)
    )
    listOf(
        Offset(cellW * 2f, cellH * 11f),
        Offset(cellW * 4f, cellH * 11f),
        Offset(cellW * 2f, cellH * 13f),
        Offset(cellW * 4f, cellH * 13f)
    ).forEach { center ->
        drawCircle(redColor, radius = cellW * 0.7f, center = center)
        drawCircle(Color.White, radius = cellW * 0.35f, center = center)
    }

    // Bottom-Right: Blue Yard
    drawRect(blueColor, Offset(cellW * 9, cellH * 9), Size(cellW * 6, cellH * 6))
    drawRoundRect(
        Color.White,
        Offset(cellW * 9.8f, cellH * 9.8f),
        Size(cellW * 4.4f, cellH * 4.4f),
        androidx.compose.ui.geometry.CornerRadius(16f, 16f)
    )
    listOf(
        Offset(cellW * 11f, cellH * 11f),
        Offset(cellW * 13f, cellH * 11f),
        Offset(cellW * 11f, cellH * 13f),
        Offset(cellW * 13f, cellH * 13f)
    ).forEach { center ->
        drawCircle(blueColor, radius = cellW * 0.7f, center = center)
        drawCircle(Color.White, radius = cellW * 0.35f, center = center)
    }

    // 2. Center Triangular Home (3x3 area: col 6..8, row 6..8)
    val centerLeft = cellW * 6
    val centerTop = cellH * 6
    val centerRight = cellW * 9
    val centerBottom = cellH * 9
    val centerMidX = cellW * 7.5f
    val centerMidY = cellH * 7.5f

    // Red Triangle (Bottom)
    val redPath = Path().apply {
        moveTo(centerLeft, centerBottom)
        lineTo(centerRight, centerBottom)
        lineTo(centerMidX, centerMidY)
        close()
    }
    drawPath(redPath, redColor)

    // Green Triangle (Left)
    val greenPath = Path().apply {
        moveTo(centerLeft, centerTop)
        lineTo(centerLeft, centerBottom)
        lineTo(centerMidX, centerMidY)
        close()
    }
    drawPath(greenPath, greenColor)

    // Yellow Triangle (Top)
    val yellowPath = Path().apply {
        moveTo(centerLeft, centerTop)
        lineTo(centerRight, centerTop)
        lineTo(centerMidX, centerMidY)
        close()
    }
    drawPath(yellowPath, yellowColor)

    // Blue Triangle (Right)
    val bluePath = Path().apply {
        moveTo(centerRight, centerTop)
        lineTo(centerRight, centerBottom)
        lineTo(centerMidX, centerMidY)
        close()
    }
    drawPath(bluePath, blueColor)

    // 3. Colored Home Columns ("পাকা পথ")
    // Red home column (col 7, rows 9 to 13)
    for (r in 9..13) {
        drawRect(redColor, Offset(cellW * 7, cellH * r), Size(cellW, cellH))
    }
    // Green home column (row 7, cols 1 to 5)
    for (c in 1..5) {
        drawRect(greenColor, Offset(cellW * c, cellH * 7), Size(cellW, cellH))
    }
    // Yellow home column (col 7, rows 1 to 5)
    for (r in 1..5) {
        drawRect(yellowColor, Offset(cellW * 7, cellH * r), Size(cellW, cellH))
    }
    // Blue home column (row 7, cols 9 to 13)
    for (c in 9..13) {
        drawRect(blueColor, Offset(cellW * c, cellH * 7), Size(cellW, cellH))
    }

    // 4. Start Squares
    drawRect(redColor, Offset(cellW * 6, cellH * 13), Size(cellW, cellH))
    drawRect(greenColor, Offset(cellW * 1, cellH * 6), Size(cellW, cellH))
    drawRect(yellowColor, Offset(cellW * 8, cellH * 1), Size(cellW, cellH))
    drawRect(blueColor, Offset(cellW * 13, cellH * 8), Size(cellW, cellH))

    // 5. Grid Lines for Cross Arms
    val gridColor = Color(0xFF64748B)
    for (i in 0..15) {
        // Vertical lines in arms
        if (i in 6..9) {
            drawLine(gridColor, Offset(cellW * i, 0f), Offset(cellW * i, h), strokeWidth = 1.5f)
        } else {
            drawLine(gridColor, Offset(cellW * i, cellH * 6), Offset(cellW * i, cellH * 9), strokeWidth = 1.5f)
        }

        // Horizontal lines in arms
        if (i in 6..9) {
            drawLine(gridColor, Offset(0f, cellH * i), Offset(w, cellH * i), strokeWidth = 1.5f)
        } else {
            drawLine(gridColor, Offset(cellW * 6, cellH * i), Offset(cellW * 9, cellH * i), strokeWidth = 1.5f)
        }
    }

    // 6. Safe Star Symbols (★) on key cells
    val starCoords = listOf(
        Offset(cellW * 6.5f, cellH * 13.5f), // Red Start
        Offset(cellW * 2.5f, cellH * 8.5f),  // Safe Left
        Offset(cellW * 1.5f, cellH * 6.5f),  // Green Start
        Offset(cellW * 6.5f, cellH * 2.5f),  // Safe Top
        Offset(cellW * 8.5f, cellH * 1.5f),  // Yellow Start
        Offset(cellW * 12.5f, cellH * 6.5f), // Safe Right
        Offset(cellW * 13.5f, cellH * 8.5f), // Blue Start
        Offset(cellW * 8.5f, cellH * 12.5f)  // Safe Bottom
    )
    starCoords.forEach { center ->
        drawCircle(safeStarColor, radius = cellW * 0.38f, center = center)
        drawCircle(Color.White, radius = cellW * 0.18f, center = center)
    }

    // 7. Golden Trophy / Crown Center Hub
    drawCircle(Color(0xFFD97706), radius = cellW * 0.9f, center = Offset(centerMidX, centerMidY))
    drawCircle(Color(0xFFF59E0B), radius = cellW * 0.7f, center = Offset(centerMidX, centerMidY))
    drawCircle(Color.White, radius = cellW * 0.3f, center = Offset(centerMidX, centerMidY))
}

/**
 * 3D High Contrast Ludo Dice Dots
 */
@Composable
fun DiceDotsView(value: Int) {
    val dotColor = if (value == 1 || value == 6) Color(0xFFDC2626) else Color(0xFF1E293B)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        when (value) {
            1 -> {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                        .shadow(2.dp, CircleShape)
                )
            }
            2 -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(13.dp).clip(CircleShape).background(dotColor))
                    Box(modifier = Modifier.size(13.dp).clip(CircleShape).background(dotColor))
                }
            }
            3 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor).align(Alignment.Start))
                    Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor).align(Alignment.CenterHorizontally))
                    Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor).align(Alignment.End))
                }
            }
            4 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(dotColor))
                    }
                }
            }
            5 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                    }
                    Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor).align(Alignment.CenterHorizontally))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                    }
                }
            }
            6 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                        Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(dotColor))
                    }
                }
            }
        }
    }
}
