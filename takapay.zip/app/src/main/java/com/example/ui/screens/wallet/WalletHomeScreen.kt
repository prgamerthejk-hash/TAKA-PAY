package com.example.ui.screens.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionRecord
import com.example.data.model.UserProfile
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.ActiveGame
import com.example.viewmodel.MainTab
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun WalletHomeScreen(
    user: UserProfile?,
    transactions: List<TransactionRecord>,
    onDepositClick: () -> Unit,
    onWithdrawClick: () -> Unit,
    onOpenSecurity: () -> Unit,
    onOpenCustomerService: () -> Unit,
    onOpenShareModal: () -> Unit,
    onOpenCertificateModal: () -> Unit,
    onClaimReward: () -> Unit,
    onNavigateTab: (MainTab) -> Unit,
    onPlayGame: (ActiveGame) -> Unit
) {
    val dateFormatter = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .testTag("wallet_home_screen")
    ) {
        // Top Header
        WalletHeader(
            user = user,
            onOpenSecurity = onOpenSecurity,
            onOpenCustomerService = onOpenCustomerService,
            onOpenShareModal = onOpenShareModal,
            onOpenCertificateModal = onOpenCertificateModal
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            // Bangladesh Legal Certificate Banner
            BangladeshCertificateBanner(
                onClick = onOpenCertificateModal
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Main Balance Card
            BalanceCard(
                user = user,
                onDepositClick = onDepositClick,
                onWithdrawClick = onWithdrawClick
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 2-3 Days Loyalty Reward
            LoyaltyRewardCard(
                user = user,
                onClaimReward = onClaimReward
            )

            Spacer(modifier = Modifier.height(14.dp))

            Spacer(modifier = Modifier.height(16.dp))

            // 24/7 Telegram Customer Service Banner Card
            TelegramCustomerServiceCard(
                onOpenCustomerService = onOpenCustomerService
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3 Games Quick Access Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateTab(MainTab.GAMES) }
                    .testTag("quick_games_banner"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, GoldenYellow.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(GoldenYellow.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = GoldenYellow,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "🎮 ৩টি গেম খেলুন ও জিতুন",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "লুডু, লেখালেখি টাস্ক ও বল গেম (৫০৳ দিয়ে ১০০৳)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = "Go",
                        tint = GoldenYellow,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Share & Install App Card (Target 01843840404)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenShareModal() }
                    .testTag("home_share_install_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, NagadOrange.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(BkashPink, NagadOrange))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "📲 অ্যাপ ইনস্টল ও শেয়ার লিংক",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                color = NagadOrange.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "০১৮৪৩৮৪০৪০৪",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NagadOrange,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ইনস্টল লিংক কপি করুন অথবা সরাসরি নাম্বারে SMS/WhatsApp করুন",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = "Share",
                        tint = NagadOrange,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Recent Transactions Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "সাম্প্রতিক লেনদেন",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                TextButton(onClick = { onNavigateTab(MainTab.HISTORY) }) {
                    Text("সব দেখুন", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (transactions.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "এখনও কোনো লেনদেন হয়নি",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                transactions.take(4).forEach { item ->
                    val isPositive = item.type == "DEPOSIT" || item.type == "GAME_WIN"
                    val itemColor = when (item.type) {
                        "DEPOSIT" -> if (item.method.contains("Nagad", true)) NagadOrange else BkashPink
                        "WITHDRAW" -> CrimsonRed
                        "GAME_WIN" -> EmeraldGreen
                        else -> Color(0xFF64748B)
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(itemColor.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (item.type) {
                                        "DEPOSIT" -> Icons.Default.AddCircle
                                        "WITHDRAW" -> Icons.Default.ArrowCircleUp
                                        "GAME_WIN" -> Icons.Default.EmojiEvents
                                        else -> Icons.Default.Casino
                                    },
                                    contentDescription = null,
                                    tint = itemColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = when (item.type) {
                                        "DEPOSIT" -> "ডিপোজিট (${item.method})"
                                        "WITHDRAW" -> "উইথড্র (${item.method})"
                                        "GAME_WIN" -> "গেম জয়ী (${item.method})"
                                        else -> "গেম বাজি (${item.method})"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = dateFormatter.format(Date(item.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            }

                            Text(
                                text = (if (isPositive) "+ ৳" else "- ৳") + item.amount.toInt(),
                                fontWeight = FontWeight.Bold,
                                color = if (isPositive) EmeraldGreen else CrimsonRed,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
